<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Auto Apply Mailer'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Auto Apply Mailer'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">

    
    <title><?php echo e($title); ?></title>

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">

    <meta
        name="csrf-token"
        content="<?php echo e(csrf_token()); ?>">

    
    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon.png')); ?>"> 
    <meta name="application-name" content="Auto Apply Mailer">
    <meta name="description" content="Auto Apply Mailer adalah aplikasi web untuk membantu pencari kerja mengelola lowongan, menyiapkan dokumen lamaran, membuat email lamaran yang dipersonalisasi, dan mengirim lamaran melalui akun email pengguna.">
    <meta name="keywords" content="manajemen lamaran kerja, lamaran kerja, pencarian kerja, email lamaran, resume, surat lamaran, Auto Apply Mailer">
    <meta name="author" content="Auto Apply Mailer">
    <meta name="robots" content="index, follow">
    <meta name="theme-color" content="#2563eb"> 
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Auto Apply Mailer">
    <meta property="og:title" content="Auto Apply Mailer — Manajemen Lamaran Kerja">
    <meta property="og:description" content="Kelola lowongan kerja, siapkan dokumen lamaran, buat email yang dipersonalisasi, dan kirim lamaran melalui akun email Anda.">
    <meta property="og:url" content="<?php echo e(url('/')); ?>">
    <meta property="og:image" content="<?php echo e(asset('og-image.png')); ?>"> 
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Auto Apply Mailer — Manajemen Lamaran Kerja">
    <meta name="twitter:description" content="Aplikasi untuk membantu pencari kerja mengelola dan mengirim lamaran kerja yang dipersonalisasi.">
    <meta name="twitter:image" content="<?php echo e(asset('og-image.png')); ?>"> 
    <link rel="canonical" href="<?php echo e(url('/')); ?>">

    

    <link rel="preconnect" href="https://fonts.bunny.net">

    <link
        href="https://fonts.bunny.net/css?family=figtree:400,500,600,700"
        rel="stylesheet" />

    <?php echo app('Illuminate\Foundation\Vite')([
    'resources/css/app.css',
    'resources/js/app.js'
    ]); ?>
</head>

<body class="font-sans antialiased text-gray-900">

    <div class="min-h-screen bg-gray-50">

        <?php echo $__env->make('layouts.navigation', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

        <?php if(isset($header)): ?>
        <header class="border-b border-gray-200 bg-white">
            <div class="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
                <?php echo e($header); ?>

            </div>
        </header>
        <?php endif; ?>

        <main>
            <?php echo e($slot); ?>

        </main>

    </div>

</body>

</html><?php /**PATH /var/www/html/resources/views/layouts/app.blade.php ENDPATH**/ ?>