<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Auto Apply Mailer'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Auto Apply Mailer'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1">

    <meta
        name="csrf-token"
        content="<?php echo e(csrf_token()); ?>">

    
    <title><?php echo e($title); ?></title>

    
    <link rel="icon" type="image/png" href="<?php echo e(asset('favicon.png')); ?>">
    <link rel="apple-touch-icon" href="<?php echo e(asset('favicon.png')); ?>">

    
    <meta name="application-name" content="Auto Apply Mailer">

    <meta
        name="description"
        content="Auto Apply Mailer adalah aplikasi web untuk membantu pencari kerja mengelola lowongan kerja, dokumen lamaran, email lamaran, dan proses pengiriman lamaran melalui akun email pengguna.">

    <meta name="author" content="Auto Apply Mailer">
    <meta name="robots" content="index, follow">

    <meta name="theme-color" content="#4f46e5">

    
    <meta property="og:type" content="website">
    <meta property="og:site_name" content="Auto Apply Mailer">
    <meta property="og:title" content="<?php echo e($title); ?>">

    <meta
        property="og:description"
        content="Aplikasi web untuk membantu pencari kerja mengelola informasi lowongan, dokumen lamaran, email lamaran, dan proses pengiriman lamaran.">

    <meta property="og:url" content="<?php echo e(url()->current()); ?>">
    <meta property="og:image" content="<?php echo e(asset('og-image.png')); ?>">

    
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="<?php echo e($title); ?>">

    <meta
        name="twitter:description"
        content="Aplikasi untuk membantu pencari kerja mengelola dan mengirim lamaran kerja.">

    <meta name="twitter:image" content="<?php echo e(asset('og-image.png')); ?>">

    
    <link rel="canonical" href="<?php echo e(url()->current()); ?>">

    <link rel="preconnect" href="https://fonts.bunny.net">

    <link
        href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap"
        rel="stylesheet">

    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="min-h-screen bg-slate-50 font-sans text-slate-900 antialiased">

    <div class="flex min-h-screen items-center justify-center px-4 py-8 sm:px-6">

        <div class="w-full sm:max-w-md">

            <div class="overflow-hidden rounded-2xl bg-white p-6 shadow-xl shadow-slate-200/70 sm:p-8">

                <?php echo e($slot); ?>


            </div>

            <div class="mt-5 text-center text-xs text-slate-400">

                <a
                    href="<?php echo e(route('privacy-policy')); ?>"
                    class="hover:text-indigo-600 hover:underline">
                    Privacy Policy
                </a>

                <span class="mx-1.5">·</span>

                <a
                    href="<?php echo e(route('terms')); ?>"
                    class="hover:text-indigo-600 hover:underline">
                    Terms of Service
                </a>

            </div>

        </div>

    </div>

</body>

</html><?php /**PATH /var/www/html/resources/views/layouts/guest.blade.php ENDPATH**/ ?>