<?php $__env->startSection('page-title', 'System Logs'); ?>

<?php $__env->startSection('content'); ?>


<div class="mb-6 flex flex-wrap items-center gap-2">
    <?php $__currentLoopData = ['all','info','warning','error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lvl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a
        href="<?php echo e(request()->fullUrlWithQuery(['level' => $lvl])); ?>"
        class="rounded-xl px-4 py-2 text-sm font-medium transition <?php echo e((request('level', 'all') == $lvl) ? 'bg-indigo-600 text-white shadow-sm' : 'border border-gray-200 bg-white text-gray-600 hover:bg-gray-50'); ?>">
        <?php echo e(ucfirst($lvl)); ?>

    </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>


<div class="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
    <div class="overflow-x-auto">
        <table class="w-full whitespace-nowrap text-left text-sm text-gray-600">
            <thead class="border-b border-gray-100 bg-gray-50/50 text-[11px] font-semibold uppercase tracking-wider text-gray-500">
                <tr>
                    <th class="px-6 py-4">Level</th>
                    <th class="px-6 py-4">Event</th>
                    <th class="px-6 py-4">Deskripsi</th>
                    <th class="px-6 py-4">User</th>
                    <th class="px-6 py-4">Waktu</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__empty_1 = true; $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="transition hover:bg-gray-50/50">
                    <td class="px-6 py-4">
                        <?php
                        $level = strtolower($log->level);
                        ?>

                        <?php if($level == 'error'): ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-rose-50 px-2 py-1 text-xs font-medium text-rose-700 ring-1 ring-inset ring-rose-600/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-rose-500"></span>
                            <?php echo e(ucfirst($log->level)); ?>

                        </span>
                        <?php elseif($level == 'warning'): ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-amber-50 px-2 py-1 text-xs font-medium text-amber-700 ring-1 ring-inset ring-amber-600/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-amber-500"></span>
                            <?php echo e(ucfirst($log->level)); ?>

                        </span>
                        <?php else: ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-sky-50 px-2 py-1 text-xs font-medium text-sky-700 ring-1 ring-inset ring-sky-600/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-sky-500"></span>
                            <?php echo e(ucfirst($log->level)); ?>

                        </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 font-medium text-gray-800"><?php echo e($log->event); ?></td>
                    <td class="px-6 py-4 text-gray-600 max-w-xs truncate" title="<?php echo e($log->description); ?>"><?php echo e($log->description); ?></td>
                    <td class="px-6 py-4 text-gray-500"><?php echo e($log->user->email ?? '-'); ?></td>
                    <td class="px-6 py-4 text-gray-400"><?php echo e($log->created_at->diffForHumans()); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="5" class="px-6 py-12 text-center text-gray-400">
                        Belum ada system log yang tercatat.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<?php if($logs->hasPages()): ?>
<div class="mt-6">
    <?php echo e($logs->links()); ?>

</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/logs/index.blade.php ENDPATH**/ ?>