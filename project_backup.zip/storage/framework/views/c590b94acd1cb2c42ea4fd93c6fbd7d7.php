<nav
    x-data="{ open: false }"
    class="sticky top-0 z-50 border-b border-gray-200/80 bg-white/95 backdrop-blur">
    <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div class="flex h-20 items-center justify-between">

            
            <div class="flex items-center">

                <a
                    href="<?php echo e(route('dashboard')); ?>"
                    class="flex items-center gap-3">

                    
                    <img
                        src="<?php echo e(asset('favicon.png')); ?>"
                        alt="Auto Apply Mailer Logo"
                        class="h-8 w-8" />

                    
                    <div class="hidden sm:block">
                        <div class="text-sm font-bold leading-5 tracking-tight text-gray-900">
                            Auto Apply
                        </div>

                        <div class="text-xs font-medium text-gray-500">
                            Mailer
                        </div>
                    </div>

                </a>


                
                <div class="ml-8 hidden items-center gap-1 sm:flex">

                    
                    <a
                        href="<?php echo e(route('dashboard')); ?>"
                        class="
                            inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition
                            focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
                            <?php echo e(request()->routeIs('dashboard')
                                ? 'bg-indigo-50 text-indigo-700'
                                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                        ">

                        <svg
                            class="h-4.5 w-4.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M3 10.5L12 3l9 7.5M5.5 9.5V21h13V9.5M9.5 21v-6h5v6" />
                        </svg>

                        Dashboard
                    </a>


                    
                    <a
                        href="<?php echo e(route('apply.index')); ?>"
                        class="
                            inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition
                            focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
                            <?php echo e(request()->routeIs('apply.*')
                                ? 'bg-indigo-50 text-indigo-700'
                                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                        ">

                        Apply Job
                    </a>

                    <a
                        href="<?php echo e(route('files.index')); ?>"
                        class="
                            inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition
                            focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
                            <?php echo e(request()->routeIs('files.*')
                                ? 'bg-indigo-50 text-indigo-700'
                                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                        ">
                        <svg
                            class="h-4.5 w-4.5"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M4 5a2 2 0 012-2h5l2 2h5a2 2 0 012 2v1H4V5zM4 8h16l-1.5 11h-13L4 8z" />
                        </svg>

                        Berkas
                    </a>

                    <a
                        href="<?php echo e(route('feedback.index')); ?>"
                        class="
                            inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition
                            focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
                            <?php echo e(request()->routeIs('feedback.*')
                                ? 'bg-indigo-50 text-indigo-700'
                                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                        ">

                        Feedback
                    </a>

                    <?php if(auth()->user()->isAdmin()): ?>
                    <a
                        href="<?php echo e(route('admin.dashboard')); ?>"
                        class="
                            inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold transition
                            focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2
                            <?php echo e(request()->routeIs('admin.*')
                                ? 'bg-indigo-50 text-indigo-700'
                                : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                        ">

                        Admin Panel
                    </a>
                    <?php endif; ?>

                </div>

            </div>


            
            <div class="hidden items-center gap-3 sm:flex">

                
                <div class="hidden text-right md:block">
                    <p class="text-sm font-bold text-gray-900">
                        <?php echo e(Auth::user()?->name ?? 'User'); ?>

                    </p>

                    <p class="mt-0.5 text-xs text-gray-500">
                        <?php echo e(Auth::user()?->email ?? ''); ?>

                    </p>
                </div>


                
                <?php if (isset($component)) { $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown','data' => ['align' => 'right','width' => '48']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['align' => 'right','width' => '48']); ?>

                     <?php $__env->slot('trigger', null, []); ?> 

                        <button
                            type="button"
                            class="flex items-center gap-2 rounded-2xl border border-gray-200 bg-white px-3 py-2.5 text-sm font-medium text-gray-700 shadow-sm transition hover:border-gray-300 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">

                            
                            <div class="flex h-9 w-9 items-center justify-center rounded-full bg-indigo-100 text-sm font-bold text-indigo-700">
                                <?php echo e(strtoupper(substr(Auth::user()?->name ?? 'U', 0, 1))); ?>

                            </div>


                            
                            <svg
                                class="h-4 w-4 text-gray-400"
                                fill="none"
                                viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path
                                    stroke-linecap="round"
                                    stroke-linejoin="round"
                                    stroke-width="2"
                                    d="M19 9l-7 7-7-7" />
                            </svg>

                        </button>

                     <?php $__env->endSlot(); ?>


                     <?php $__env->slot('content', null, []); ?> 

                        
                        <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('profile.edit')]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('profile.edit'))]); ?>
                            <div class="flex items-center gap-2">

                                <svg
                                    class="h-4 w-4 text-gray-400"
                                    fill="none"
                                    viewBox="0 0 24 24"
                                    stroke="currentColor">
                                    <path
                                        stroke-linecap="round"
                                        stroke-linejoin="round"
                                        stroke-width="2"
                                        d="M15 19a4 4 0 00-8 0M11 11a4 4 0 100-8 4 4 0 000 8z" />
                                </svg>

                                Profile

                            </div>
                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>


                        
                        <form
                            method="POST"
                            action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>

                            <?php if (isset($component)) { $__componentOriginal68cb1971a2b92c9735f83359058f7108 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal68cb1971a2b92c9735f83359058f7108 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.dropdown-link','data' => ['href' => route('logout'),'onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dropdown-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(route('logout')),'onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']); ?>
                                <div class="flex items-center gap-2 text-red-600">

                                    <svg
                                        class="h-4 w-4"
                                        fill="none"
                                        viewBox="0 0 24 24"
                                        stroke="currentColor">
                                        <path
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                            stroke-width="2"
                                            d="M15 17l5-5-5-5M20 12H9M12 19H6a2 2 0 01-2-2V7a2 2 0 012-2h6" />
                                    </svg>

                                    Logout

                                </div>
                             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $attributes = $__attributesOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__attributesOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal68cb1971a2b92c9735f83359058f7108)): ?>
<?php $component = $__componentOriginal68cb1971a2b92c9735f83359058f7108; ?>
<?php unset($__componentOriginal68cb1971a2b92c9735f83359058f7108); ?>
<?php endif; ?>

                        </form>

                     <?php $__env->endSlot(); ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $attributes = $__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__attributesOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe)): ?>
<?php $component = $__componentOriginaldf8083d4a852c446488d8d384bbc7cbe; ?>
<?php unset($__componentOriginaldf8083d4a852c446488d8d384bbc7cbe); ?>
<?php endif; ?>

            </div>


            
            <div class="flex items-center sm:hidden">

                <button
                    type="button"
                    @click="open = !open"
                    class="inline-flex items-center justify-center rounded-xl border border-gray-200 bg-white p-2.5 text-gray-500 shadow-sm transition hover:bg-gray-50 hover:text-gray-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">

                    
                    <svg
                        x-show="!open"
                        x-cloak
                        class="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M4 6h16M4 12h16M4 18h16" />
                    </svg>


                    
                    <svg
                        x-show="open"
                        x-cloak
                        class="h-5 w-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M6 18L18 6M6 6l12 12" />
                    </svg>

                </button>

            </div>

        </div>
    </div>


    
    <div
        x-show="open"
        x-transition:enter="transition ease-out duration-200"
        x-transition:enter-start="opacity-0 -translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0"
        x-transition:leave="transition ease-in duration-150"
        x-transition:leave-start="opacity-100 translate-y-0"
        x-transition:leave-end="opacity-0 -translate-y-2"
        class="border-t border-gray-100 bg-white sm:hidden">

        <div class="space-y-1 px-4 py-4">

            
            <a
                href="<?php echo e(route('dashboard')); ?>"
                class="
                    flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition
                    <?php echo e(request()->routeIs('dashboard')
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                ">

                <span class="text-base">
                    🏠
                </span>

                Dashboard

            </a>


            
            <a
                href="<?php echo e(route('apply.index')); ?>"
                class="
                    flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition
                    <?php echo e(request()->routeIs('apply.*')
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                ">

                <span class="text-base">
                    ✉️
                </span>

                Apply Job

            </a>

            <a
                href="<?php echo e(route('files.index')); ?>"
                class="
                    flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition
                    <?php echo e(request()->routeIs('files.*')
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                ">
                <span class="text-base">
                    📁
                </span>

                Berkas
            </a>

            <a
                href="<?php echo e(route('feedback.index')); ?>"
                class="
                    flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition
                    <?php echo e(request()->routeIs('feedback.*')
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                ">
                <span class="text-base">
                    📁
                </span>

                Feedback
            </a>

            <?php if(auth()->user()->isAdmin()): ?>
            <a
                href="<?php echo e(route('admin.dashboard')); ?>"
                class="
                    flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-semibold transition
                    <?php echo e(request()->routeIs('admin.*')
                        ? 'bg-indigo-50 text-indigo-700'
                        : 'text-gray-600 hover:bg-gray-50 hover:text-gray-900'); ?>

                ">
                <span class="text-base">
                    📁
                </span>

                Admin Panel
            </a>
            <?php endif; ?>

        </div>


        
        <div class="border-t border-gray-100 px-4 py-4">

            <div class="flex items-center gap-3">

                
                <div class="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-indigo-100 text-sm font-bold text-indigo-700">
                    <?php echo e(strtoupper(substr(Auth::user()?->name ?? 'U', 0, 1))); ?>

                </div>


                
                <div class="min-w-0">

                    <p class="truncate text-sm font-bold text-gray-900">
                        <?php echo e(Auth::user()?->name ?? 'User'); ?>

                    </p>

                    <p class="truncate text-xs text-gray-500">
                        <?php echo e(Auth::user()?->email ?? ''); ?>

                    </p>

                </div>

            </div>


            <div class="mt-4 space-y-1">

                
                <a
                    href="<?php echo e(route('profile.edit')); ?>"
                    class="flex items-center gap-3 rounded-xl px-4 py-3 text-sm font-medium text-gray-600 transition hover:bg-gray-50 hover:text-gray-900">
                    <svg
                        class="h-4 w-4 text-gray-400"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path
                            stroke-linecap="round"
                            stroke-linejoin="round"
                            stroke-width="2"
                            d="M15 19a4 4 0 00-8 0M11 11a4 4 0 100-8 4 4 0 000 8z" />
                    </svg>

                    Profile
                </a>


                
                <form
                    method="POST"
                    action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>

                    <button
                        type="submit"
                        class="flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left text-sm font-medium text-red-600 transition hover:bg-red-50">

                        <svg
                            class="h-4 w-4"
                            fill="none"
                            viewBox="0 0 24 24"
                            stroke="currentColor">
                            <path
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                stroke-width="2"
                                d="M15 17l5-5-5-5M20 12H9M12 19H6a2 2 0 01-2-2V7a2 2 0 012-2h6" />
                        </svg>

                        Logout

                    </button>

                </form>

            </div>

        </div>

    </div>

</nav><?php /**PATH /var/www/html/resources/views/layouts/navigation.blade.php ENDPATH**/ ?>