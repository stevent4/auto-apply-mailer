<?php $__env->startSection('page-title', 'Management Users'); ?>

<?php $__env->startSection('content'); ?>

<div class="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
    <div class="overflow-x-auto">
        <table class="w-full whitespace-nowrap text-left text-sm text-gray-600">
            <thead class="border-b border-gray-100 bg-gray-50/50 text-[11px] font-semibold uppercase tracking-wider text-gray-500">
                <tr>
                    <th class="px-6 py-4">Nama</th>
                    <th class="px-6 py-4">Email</th>
                    <th class="px-6 py-4">Registrasi</th>
                    <th class="px-6 py-4">Total Lamaran</th>
                    <th class="px-6 py-4">Status</th>
                    <th class="px-6 py-4">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="transition hover:bg-gray-50/50">
                    <td class="px-6 py-4 font-medium text-gray-700"><?php echo e($user->name); ?></td>
                    <td class="px-6 py-4 text-gray-500"><?php echo e($user->email); ?></td>
                    <td class="px-6 py-4 text-gray-500"><?php echo e($user->created_at->format('d M Y')); ?></td>
                    <td class="px-6 py-4 text-gray-500"><?php echo e($user->application_histories_count ?? 0); ?></td>
                    <td class="px-6 py-4">
                        <?php if($user->status == 'suspended'): ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-rose-50 px-2 py-1 text-xs font-medium text-rose-700">
                            <span class="h-1.5 w-1.5 rounded-full bg-rose-500"></span> Suspended
                        </span>
                        <?php else: ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-emerald-50 px-2 py-1 text-xs font-medium text-emerald-700">
                            <span class="h-1.5 w-1.5 rounded-full bg-emerald-500"></span> Active
                        </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4">
                        <div class="flex items-center gap-4">
                            <a href="<?php echo e(route('admin.users.show', $user)); ?>" class="font-medium text-indigo-600 transition-colors hover:text-indigo-800">
                                Detail
                            </a>

                            <?php if(($user->status ?? 'active') === 'active'): ?>
                            <form method="POST" action="<?php echo e(route('admin.users.suspend', $user)); ?>" class="inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="font-medium text-rose-500 transition-colors hover:text-rose-700">
                                    Suspend
                                </button>
                            </form>
                            <?php else: ?>
                            <form method="POST" action="<?php echo e(route('admin.users.activate', $user)); ?>" class="inline">
                                <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                <button type="submit" class="font-medium text-emerald-600 transition-colors hover:text-emerald-800">
                                    Aktifkan
                                </button>
                            </form>
                            <?php endif; ?>
                            <form action="<?php echo e(route('admin.users.destroy', $user->id)); ?>" method="POST" class="inline-block" onsubmit="return confirm('Apakah Anda yakin ingin menghapus pengguna ini beserta seluruh berkasnya?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="font-medium text-rose-500 transition-colors hover:text-rose-700">
                                    Hapus
                                </button>
                            </form>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-12 text-center text-gray-400">
                        Belum ada data pengguna.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<?php if($users->hasPages()): ?>
<div class="mt-6">
    <?php echo e($users->links()); ?>

</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/users/index.blade.php ENDPATH**/ ?>