<?php $__env->startSection('page-title', 'Detail Feedback & Report'); ?>

<?php $__env->startSection('content'); ?>


<div class="mb-6">
    <a href="<?php echo e(route('admin.feedback.index')); ?>" class="inline-flex items-center gap-2 text-sm font-medium text-gray-500 transition-colors hover:text-gray-900">
        <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
        </svg>
        Kembali ke Daftar Feedback
    </a>
</div>


<div class="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm sm:p-8">
    <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
        <div>
            <h1 class="text-xl font-semibold text-gray-800"><?php echo e($feedback->title); ?></h1>
            <p class="mt-1 text-sm text-gray-400">
                <span class="font-medium text-gray-700"><?php echo e($feedback->user->name ?? 'User'); ?></span> (<?php echo e($feedback->user->email ?? '-'); ?>) &middot;
                <span class="inline-flex items-center rounded-md bg-gray-100 px-2 py-0.5 text-xs font-medium text-gray-700"><?php echo e(ucfirst($feedback->type)); ?></span> &middot;
                <?php echo e($feedback->created_at->format('d M Y H:i')); ?>

            </p>
        </div>

        
        <form method="POST" action="<?php echo e(route('admin.feedback.update-status', $feedback)); ?>" class="shrink-0">
            <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
            <select
                name="status"
                onchange="this.form.submit()"
                class="rounded-xl border border-gray-200 bg-white px-3 py-1.5 text-sm font-medium text-gray-700 outline-none transition focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500">
                <?php $__currentLoopData = ['open','in_progress','resolved','closed']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($s); ?>" <?php if($feedback->status == $s): echo 'selected'; endif; ?>><?php echo e(ucfirst(str_replace('_',' ',$s))); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </form>
    </div>

    
    <div class="mt-6 text-gray-600 leading-relaxed">
        <p><?php echo e($feedback->description); ?></p>
    </div>

    
    <?php if($feedback->screenshot_path): ?>
    <div class="mt-6">
        <p class="mb-2 text-xs font-semibold uppercase tracking-wider text-gray-400">Lampiran Screenshot:</p>
        <a href="<?php echo e(asset('storage/'.$feedback->screenshot_path)); ?>" target="_blank" class="inline-block overflow-hidden rounded-xl border border-gray-200 transition hover:opacity-90">
            <img src="<?php echo e(asset('storage/'.$feedback->screenshot_path)); ?>" class="max-h-80 w-auto object-cover">
        </a>
    </div>
    <?php endif; ?>

    
    <?php if($feedback->relatedApplication): ?>
    <div class="mt-6 rounded-xl border border-indigo-100 bg-indigo-50/50 p-4 text-sm text-indigo-900">
        <span class="font-semibold">Terkait Lamaran:</span>
        Ke perusahaan <strong class="text-indigo-700"><?php echo e($feedback->relatedApplication->company_name); ?></strong>
        (Status: <span class="capitalize font-medium"><?php echo e($feedback->relatedApplication->status); ?></span>)
    </div>
    <?php endif; ?>
</div>


<div class="mt-8">
    <h2 class="mb-4 text-base font-semibold text-gray-700">Percakapan</h2>

    <div class="space-y-4">
        <?php $__empty_1 = true; $__currentLoopData = $feedback->replies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
            <div class="mb-2 flex items-center justify-between">
                <span class="text-xs font-semibold text-gray-800"><?php echo e($reply->user->name ?? 'Admin/User'); ?></span>
                <span class="text-xs text-gray-400"><?php echo e($reply->created_at->diffForHumans()); ?></span>
            </div>
            <p class="text-sm text-gray-600 leading-relaxed"><?php echo e($reply->message); ?></p>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="rounded-2xl border border-gray-100 bg-white p-8 text-center text-sm text-gray-400 shadow-sm">
            Belum ada balasan pada percakapan ini.
        </div>
        <?php endif; ?>
    </div>

    
    <form method="POST" action="<?php echo e(route('admin.feedback.reply', $feedback)); ?>" class="mt-6 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
        <?php echo csrf_field(); ?>
        <label for="message" class="mb-2 block text-sm font-medium text-gray-700">Tulis Balasan</label>
        <textarea
            name="message"
            id="message"
            rows="4"
            class="w-full rounded-xl border border-gray-200 p-3 text-sm text-gray-700 outline-none transition focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500"
            placeholder="Tulis pesan balasan untuk pengguna..."
            required></textarea>

        <div class="mt-4 flex justify-end">
            <button
                type="submit"
                class="inline-flex items-center justify-center rounded-xl bg-indigo-600 px-5 py-2 text-sm font-medium text-white transition hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1">
                Kirim Balasan
            </button>
        </div>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/feedback/show.blade.php ENDPATH**/ ?>