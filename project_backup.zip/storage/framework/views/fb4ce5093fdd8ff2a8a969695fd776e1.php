<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['title' => 'Kirim Feedback — Auto Apply Mailer']); ?>

    <div class="min-h-screen bg-gray-50">
        <div class="mx-auto max-w-4xl px-4 py-8 sm:px-6 lg:px-8">

            
            <div class="mb-7">
                <div class="flex items-center justify-between gap-4">

                    <div>
                        <h1 class="text-2xl font-semibold tracking-tight text-gray-900">
                            Kirim Feedback
                        </h1>

                        <p class="mt-1 text-sm text-gray-500">
                            Sampaikan saran atau laporkan masalah yang kamu temui.
                        </p>
                    </div>

                    <a
                        href="<?php echo e(route('feedback.index')); ?>"
                        class="text-sm font-medium text-gray-500 transition hover:text-gray-900">
                        Kembali
                    </a>

                </div>
            </div>


            
            <div class="rounded-2xl border border-gray-200 bg-white shadow-sm">

                <form
                    method="POST"
                    action="<?php echo e(route('feedback.store')); ?>"
                    enctype="multipart/form-data">

                    <?php echo csrf_field(); ?>

                    <div class="space-y-6 p-6 sm:p-8">

                        
                        <div>
                            <label
                                for="type"
                                class="mb-2 block text-sm font-medium text-gray-800">
                                Jenis
                            </label>

                            <select
                                id="type"
                                name="type"
                                required
                                class="w-full rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm text-gray-900 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10">

                                <option value="feedback" <?php if(old('type', 'feedback' )==='feedback' ): echo 'selected'; endif; ?>>
                                    Feedback / Saran
                                </option>

                                <option value="report" <?php if(old('type')==='report' ): echo 'selected'; endif; ?>>
                                    Laporkan Masalah
                                </option>

                            </select>

                            <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600">
                                <?php echo e($message); ?>

                            </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        
                        <div>
                            <label
                                for="category"
                                class="mb-2 block text-sm font-medium text-gray-800">
                                Kategori
                                <span class="font-normal text-gray-400">(opsional)</span>
                            </label>

                            <input
                                id="category"
                                type="text"
                                name="category"
                                value="<?php echo e(old('category')); ?>"
                                placeholder="Contoh: Email, CV, UI"
                                class="w-full rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm text-gray-900 placeholder-gray-400 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10">

                            <?php $__errorArgs = ['category'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600">
                                <?php echo e($message); ?>

                            </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        
                        <div>
                            <label
                                for="title"
                                class="mb-2 block text-sm font-medium text-gray-800">
                                Judul
                            </label>

                            <input
                                id="title"
                                type="text"
                                name="title"
                                value="<?php echo e(old('title')); ?>"
                                required
                                placeholder="Tulis judul feedback"
                                class="w-full rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm text-gray-900 placeholder-gray-400 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10">

                            <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600">
                                <?php echo e($message); ?>

                            </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        
                        <div>
                            <label
                                for="description"
                                class="mb-2 block text-sm font-medium text-gray-800">
                                Deskripsi
                            </label>

                            <textarea
                                id="description"
                                name="description"
                                rows="6"
                                required
                                placeholder="Jelaskan feedback atau masalah yang kamu alami..."
                                class="w-full resize-y rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm leading-6 text-gray-900 placeholder-gray-400 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10"><?php echo e(old('description')); ?></textarea>

                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600">
                                <?php echo e($message); ?>

                            </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>


                        
                        <?php if($applications->count()): ?>

                        <div>
                            <label
                                for="related_application_id"
                                class="mb-2 block text-sm font-medium text-gray-800">
                                Lamaran terkait
                                <span class="font-normal text-gray-400">(opsional)</span>
                            </label>

                            <select
                                id="related_application_id"
                                name="related_application_id"
                                class="w-full rounded-xl border border-gray-300 bg-white px-4 py-3 text-sm text-gray-900 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-500/10">

                                <option value="">
                                    Tidak ada
                                </option>

                                <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option
                                    value="<?php echo e($app->id); ?>"
                                    <?php if(old('related_application_id')==$app->id): echo 'selected'; endif; ?>>
                                    <?php echo e($app->company_name); ?> — <?php echo e($app->position); ?>

                                </option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                            <?php $__errorArgs = ['related_application_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600">
                                <?php echo e($message); ?>

                            </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <?php endif; ?>


                        
                        <div>
                            <label
                                for="screenshot"
                                class="mb-2 block text-sm font-medium text-gray-800">
                                Screenshot
                                <span class="font-normal text-gray-400">(opsional)</span>
                            </label>

                            <input
                                id="screenshot"
                                type="file"
                                name="screenshot"
                                accept="image/*"
                                class="block w-full rounded-xl border border-gray-300 bg-white px-4 py-2.5 text-sm text-gray-500
                                file:mr-3 file:rounded-lg file:border-0 file:bg-gray-100
                                file:px-4 file:py-2 file:text-sm file:font-medium file:text-gray-700
                                hover:file:bg-gray-200">

                            <?php $__errorArgs = ['screenshot'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <p class="mt-1.5 text-xs text-red-600">
                                <?php echo e($message); ?>

                            </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

                            <p class="mt-1.5 text-xs text-gray-400">
                                Maksimal 2MB.
                            </p>
                        </div>

                    </div>


                    
                    <div class="flex flex-col-reverse gap-3 border-t border-gray-100 px-6 py-5 sm:flex-row sm:items-center sm:justify-end sm:px-8">

                        <a
                            href="<?php echo e(route('feedback.index')); ?>"
                            class="inline-flex justify-center rounded-xl px-5 py-2.5 text-sm font-medium text-gray-600 transition hover:bg-gray-100 hover:text-gray-900">
                            Batal
                        </a>

                        <button
                            type="submit"
                            class="inline-flex justify-center rounded-xl bg-indigo-600 px-5 py-2.5 text-sm font-medium text-white transition hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2">
                            Kirim Feedback
                        </button>

                    </div>

                </form>

            </div>

        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH /var/www/html/resources/views/feedback/create.blade.php ENDPATH**/ ?>