<?php $__env->startSection('page-title', 'Feedback & Reports'); ?>

<?php $__env->startSection('content'); ?>


<form method="GET" class="mb-6 flex flex-col gap-3 sm:flex-row">
    
    <select
        name="type"
        class="w-full rounded-xl border border-gray-200 bg-white px-4 py-2 text-sm text-gray-700 outline-none transition focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 sm:w-48">
        <option value="">Semua Tipe</option>
        <option value="feedback" <?php if(request('type')=='feedback' ): echo 'selected'; endif; ?>>Feedback</option>
        <option value="report" <?php if(request('type')=='report' ): echo 'selected'; endif; ?>>Report</option>
    </select>

    
    <select
        name="status"
        class="w-full rounded-xl border border-gray-200 bg-white px-4 py-2 text-sm text-gray-700 outline-none transition focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 sm:w-48">
        <option value="">Semua Status</option>
        <option value="open" <?php if(request('status')=='open' ): echo 'selected'; endif; ?>>Open</option>
        <option value="in_progress" <?php if(request('status')=='in_progress' ): echo 'selected'; endif; ?>>In Progress</option>
        <option value="resolved" <?php if(request('status')=='resolved' ): echo 'selected'; endif; ?>>Resolved</option>
        <option value="closed" <?php if(request('status')=='closed' ): echo 'selected'; endif; ?>>Closed</option>
    </select>

    
    <button
        type="submit"
        class="inline-flex items-center justify-center gap-2 rounded-xl bg-indigo-600 px-5 py-2 text-sm font-medium text-white transition hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-1">
        Filter
    </button>
</form>


<div class="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
    <div class="overflow-x-auto">
        <table class="w-full whitespace-nowrap text-left text-sm text-gray-600">
            <thead class="border-b border-gray-100 bg-gray-50/50 text-[11px] font-semibold uppercase tracking-wider text-gray-500">
                <tr>
                    <th class="px-6 py-4">User</th>
                    <th class="px-6 py-4">Tipe</th>
                    <th class="px-6 py-4">Judul</th>
                    <th class="px-6 py-4">Status</th>
                    <th class="px-6 py-4">Waktu</th>
                    <th class="px-6 py-4">Aksi</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__empty_1 = true; $__currentLoopData = $feedbacks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="transition hover:bg-gray-50/50">
                    <td class="px-6 py-4 font-medium text-gray-800"><?php echo e($fb->user->name ?? '-'); ?></td>
                    <td class="px-6 py-4">
                        <span class="inline-flex items-center rounded-md bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-700">
                            <?php echo e(ucfirst($fb->type)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 font-medium text-gray-700"><?php echo e($fb->title); ?></td>
                    <td class="px-6 py-4">
                        
                        <?php
                        $status = strtolower($fb->status);
                        ?>

                        <?php if($status == 'resolved'): ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-emerald-50 px-2 py-1 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                            Resolved
                        </span>
                        <?php elseif($status == 'in_progress'): ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-amber-50 px-2 py-1 text-xs font-medium text-amber-700 ring-1 ring-inset ring-amber-600/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-amber-500"></span>
                            In Progress
                        </span>
                        <?php elseif($status == 'open'): ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-sky-50 px-2 py-1 text-xs font-medium text-sky-700 ring-1 ring-inset ring-sky-600/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-sky-500"></span>
                            Open
                        </span>
                        <?php else: ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-gray-50 px-2 py-1 text-xs font-medium text-gray-600 ring-1 ring-inset ring-gray-500/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-gray-400"></span>
                            <?php echo e(ucfirst($fb->status)); ?>

                        </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-gray-400"><?php echo e($fb->created_at->diffForHumans()); ?></td>
                    <td class="px-6 py-4">
                        <a href="<?php echo e(route('admin.feedback.show', $fb)); ?>" class="font-medium text-indigo-600 transition-colors hover:text-indigo-800">
                            Lihat
                        </a>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-12 text-center text-gray-400">
                        Belum ada data feedback atau laporan yang masuk.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>


<?php if($feedbacks->hasPages()): ?>
<div class="mt-6">
    <?php echo e($feedbacks->links()); ?>

</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/feedback/index.blade.php ENDPATH**/ ?>