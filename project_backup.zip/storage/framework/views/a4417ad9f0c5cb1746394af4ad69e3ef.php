<?php $__env->startSection('page-title', 'Detail Pengguna'); ?>

<?php $__env->startSection('content'); ?>


<div class="mb-6">
    <a href="<?php echo e(route('admin.users.index')); ?>" class="inline-flex items-center gap-2 text-sm font-medium text-gray-500 transition-colors hover:text-gray-900">
        <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
        </svg>
        Kembali ke Daftar Users
    </a>
</div>


<div class="mb-8 flex items-center gap-5 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
    
    <div class="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-indigo-50 text-xl font-bold text-indigo-700">
        <?php echo e(strtoupper(substr($user->name, 0, 1))); ?>

    </div>

    <div>
        <h1 class="text-xl font-semibold text-gray-800"><?php echo e($user->name); ?></h1>
        <p class="text-sm font-medium text-gray-500"><?php echo e($user->email); ?></p>

        <div class="mt-2 flex items-center gap-1.5 text-xs font-medium text-gray-400">
            <svg class="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            Bergabung sejak <?php echo e($user->created_at->format('d M Y')); ?>

        </div>
    </div>
</div>


<div class="mb-4">
    <h2 class="text-base font-semibold text-gray-700">Riwayat Lamaran</h2>
</div>


<div class="overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm">
    <div class="overflow-x-auto">
        <table class="w-full whitespace-nowrap text-left text-sm text-gray-600">
            <thead class="border-b border-gray-100 bg-gray-50/50 text-[11px] font-semibold uppercase tracking-wider text-gray-500">
                <tr>
                    <th class="px-6 py-4">Perusahaan</th>
                    <th class="px-6 py-4">Posisi</th>
                    <th class="px-6 py-4">Status</th>
                    <th class="px-6 py-4">Waktu</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-50">
                <?php $__empty_1 = true; $__currentLoopData = $user->applicationHistories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $app): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="transition hover:bg-gray-50/50">
                    <td class="px-6 py-4 font-medium text-gray-700"><?php echo e($app->nama_pt); ?></td>
                    <td class="px-6 py-4 text-gray-500"><?php echo e($app->posisi); ?></td>
                    <td class="px-6 py-4">
                        
                        <?php if(strtolower($app->status) == 'berhasil' || strtolower($app->status) == 'success' || strtolower($app->status) == 'sent'): ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-emerald-50 px-2 py-1 text-xs font-medium text-emerald-700 ring-1 ring-inset ring-emerald-600/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                            <?php echo e($app->status); ?>

                        </span>
                        <?php elseif(strtolower($app->status) == 'gagal' || strtolower($app->status) == 'failed'): ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-rose-50 px-2 py-1 text-xs font-medium text-rose-700 ring-1 ring-inset ring-rose-600/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-rose-500"></span>
                            <?php echo e($app->status); ?>

                        </span>
                        <?php else: ?>
                        <span class="inline-flex items-center gap-1.5 rounded-md bg-gray-50 px-2 py-1 text-xs font-medium text-gray-600 ring-1 ring-inset ring-gray-500/20">
                            <span class="h-1.5 w-1.5 rounded-full bg-gray-400"></span>
                            <?php echo e($app->status); ?>

                        </span>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 text-gray-400"><?php echo e($app->created_at->diffForHumans()); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="4" class="px-6 py-12 text-center text-gray-400">
                        Pengguna ini belum memiliki riwayat lamaran.
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/html/resources/views/admin/users/show.blade.php ENDPATH**/ ?>